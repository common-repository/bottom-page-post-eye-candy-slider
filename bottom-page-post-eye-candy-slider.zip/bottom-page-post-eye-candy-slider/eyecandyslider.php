<?php ob_start();
/*
 * Plugin Name: Bottom Page Post Eye Candy Slider
 * Plugin URI: http://internetmarketingscout.com/eyecandyslider/
 * Description: Add A Eye Catching Slider To Your Page/Post
 * Author: Duncan-Internet Marketing Scout
 * Version: 1.1 beta
 * Author URI: http://internetmarketingscout.com/
 */


 
//Add Admin Menu
function add_eyecandyslider_menu() {
    add_options_page('Eye Candy Slider', 'Eye Candy Slider', 'manage_options', 'bottom-page-post-eye-candy-slider', 'admin_eyecandyslider');
}

add_action('admin_menu', 'add_eyecandyslider_menu');

// For Color Picker Options
add_action( 'admin_enqueue_scripts', 'mw_enqueue_color_pickr' );
function mw_enqueue_color_pickr( $hook_suffix ) {
    // first check that $hook_suffix is appropriate for your admin page
    wp_enqueue_script( 'my-script-handler', plugins_url('my-script.js', __FILE__ ));
}

add_action( 'admin_enqueue_scripts', 'mw_enqueue_color_picker' );
function mw_enqueue_color_picker( $hook_suffix ) {
    // first check that $hook_suffix is appropriate for your admin page
    wp_enqueue_style( 'wp-color-picker' );
    wp_enqueue_script( 'my-script-handle', plugins_url('my-script.js', __FILE__ ), array( 'wp-color-picker' ), false, true );
}

//wp_enqueue_script('wp-color-picker');

// Add Options in DB
function set_eyecandyslider_options() {
      add_option('eyecandyslider_style', 'default');
      add_option('eyecandyslider_cookie', 'default');
      add_option('c2_eyecandyslider', '7');
      add_option('c2_popuptitle', 'Demo Eye Candy Slider');
      add_option('c2_popupcontent', 'Testing Eye Candy Slider');
      add_option('readmore', site_url());
      add_option('slidername', 'Eye Candy');
      add_option('c2_drop', 'default');
      add_option('c2_drophor', '3');
      add_option('c2_popupbg', '#EAEAEA');
      add_option('c2_dropver', '3');
      add_option('c2_dropblur', '4');
      add_option('c2_dropcolor', '#effeff');
      add_option('c2_bortype', 'solid');
      add_option('c2_borcolor', '#d6d6d6');
      add_option('c2_height', '270');
      add_option('c2_width', '420');
      add_option('c2_borwidth', '1');
      add_option('c2_rc', '5');
      add_option('eyecandy_page_option', '1');
      add_option('c2_slide', 'right');
      
}
// For admin section tabs
function writeAdminHeader() {
  $default_c2_popupcontent = get_option('c2_popupcontent');
        $default_c2_popuptitle = get_option('c2_popuptitle');
            echo "<link rel='stylesheet' type='text/css' href='".plugins_url('css/ezTabs.css', __FILE__)."' />";
            echo "<link rel='stylesheet' type='text/css' href='".plugins_url('css/dragslider.css', __FILE__)."' />";
            echo '<script type="text/javascript" src="'.plugins_url('js/ezTabs.js', __FILE__).'"></script>';
            echo '<script type="text/javascript" src="'.plugins_url('js/ezToolTip.js', __FILE__).'"></script>';
            echo '<script src="'.plugins_url('js/codemirror.js', __FILE__).'" type="text/javascript"></script>
            <script src="'.plugins_url('js/mootools-core-1.4-full.js', __FILE__).'" type="text/javascript"></script>
            <script src="'.plugins_url('js/mootools-more-1.4-full.js', __FILE__).'" type="text/javascript"></script>';
            ?>
<script type="text/javascript" language="javascript">// <![CDATA[
// delete cookies function
function clearCookie(name, domain, path){
    var domain = domain || document.domain;
    var path = path || "/";
    document.cookie = name + "=; expires=" + +new Date + ";  path=/";
    alert('Cookies deleted!');
    return false;
};
// ]]></script>
  <?php  }
// Unset Option on deactivation of Plugin
function unset_eyecandyslider_options() {
      delete_option('eyecandyslider_style');
      delete_option('eyecandyslider_cookie');
      delete_option('c2_eyecandyslider');
      delete_option('c2_popuptitle');
      delete_option('c2_popupcontent');
      delete_option('readmore');
      delete_option('slidername');
      delete_option('c2_drop');
      delete_option('c2_drophor');
      delete_option('c2_dropver');
      delete_option('c2_dropblur');
      delete_option('c2_dropcolor');
      delete_option('c2_bortype');
      delete_option('c2_borcolor');
      delete_option('c2_height');
      delete_option('c2_width');
      delete_option('c2_tempbg');
      delete_option('c2_rc');
      delete_option('eyecandy_page_option');
      delete_option('c2_slide');
      delete_option('c2_audio');
      	
  
}


register_activation_hook(__FILE__, 'set_eyecandyslider_options');
register_deactivation_hook(__FILE__, 'unset_eyecandyslider_options');

// Customization of PopUp attributes from Admin
function admin_eyecandyslider() {
	writeAdminHeader();
    ?>

    <div class="wrap">
        <div class="icon32" id="icon-options-general"><br /></div>
        
        <?php
        if (!empty($_POST) && check_admin_referer('eyecandyslider_nonce_action', 'eyecandyslider_nonce_field')) {
          
            update_eyecandyslider_options();
           
        }
         echo '<h2>Eye Candy Slider Settings</h2>';
          print_eyecandyslider_form();
        
        ?>
    </div>
    <?php
}



// For Updating options for Popup from admin
function update_eyecandyslider_options() {
    $correto = false;
  
    // Layout for plugin
    if ($_REQUEST['eyecandyslider_style']) {
          update_option('eyecandyslider_style', $_REQUEST['eyecandyslider_style']);
          $correto = true;
      }
      if ($_REQUEST['eyecandyslider_cookie']) {
          update_option('eyecandyslider_cookie', $_REQUEST['eyecandyslider_cookie']);
          $correto = true;
      }

    if ($_REQUEST['c2_eyecandyslider']) {
          update_option('c2_eyecandyslider', $_REQUEST['c2_eyecandyslider']);
          $correto = true;
      }
           
      if ($_REQUEST['c2_popuptitle']) {
        $default_c2_popuptitle = get_option('c2_popuptitle');
        update_option('c2_popuptitle', $_REQUEST['c2_popuptitle']);
        $correto = true;
    }
	if ($_REQUEST['c2_popupcontent']) {
    $default_c2_popupcontent = get_option('c2_popupcontent');
        update_option('c2_popupcontent', $_REQUEST['c2_popupcontent']);
        $correto = true;
    }
    if ($_REQUEST['slidername']) {
        $default_c2_popuptitle = get_option('slidername');
        update_option('slidername', $_REQUEST['slidername']);
        $correto = true;
    }
	if ($_REQUEST['readmore']) {
    $default_c2_popupcontent = get_option('readmore');
        update_option('readmore', $_REQUEST['readmore']);
        $correto = true;
    }
    
    if ($_REQUEST['c2_drop']) {
        update_option('c2_drop', $_REQUEST['c2_drop']);
        $correto = true;
    }
    if ($_REQUEST['c2_drophor']) {
       $str=explode("px", $_REQUEST['c2_drophor']);
        update_option('c2_drophor', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_dropver']) {
      $str=explode("px", $_REQUEST['c2_dropver']);
        update_option('c2_dropver', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_dropblur']) {
       $str=explode("px", $_REQUEST['c2_dropblur']);
        update_option('c2_dropblur', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_dropcolor']) {
        update_option('c2_dropcolor', $_REQUEST['c2_dropcolor']);
        $correto = true;
    }
    if ($_REQUEST['c2_bortype']) {
        update_option('c2_bortype', $_REQUEST['c2_bortype']);
        $correto = true;
    }
    if ($_REQUEST['c2_borcolor']) {
        update_option('c2_borcolor', $_REQUEST['c2_borcolor']);
        $correto = true;
    }
    if ($_REQUEST['c2_height']) {
      $str=explode("px", $_REQUEST['c2_height']);
        update_option('c2_height', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_width']) {
       $str=explode("px", $_REQUEST['c2_width']);
        update_option('c2_width', $str[0]);
        $correto = true;
    }
    
    if ($_REQUEST['c2_rc']) {
      $str=explode("px", $_REQUEST['c2_rc']);
        update_option('c2_rc', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_borwidth']) {
      $str=explode("px", $_REQUEST['c2_borwidth']);
        update_option('c2_borwidth', $str[0]);
        $correto = true;
    }
     if ($_REQUEST['c2_left']) {
       $str=explode("%", $_REQUEST['c2_left']);
        update_option('c2_left', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_top']) {
       $str=explode("%", $_REQUEST['c2_top']);
        update_option('c2_top', $str[0]);
        $correto = true;
    }
     if ($_REQUEST['c2_right']) {
       $str=explode("%", $_REQUEST['c2_right']);
        update_option('c2_right', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['c2_bottom']) {
       $str=explode("%", $_REQUEST['c2_bottom']);
        update_option('c2_bottom', $str[0]);
        $correto = true;
    }
    if ($_REQUEST['eyecandy_page_option']) {
        update_option('eyecandy_page_option', $_REQUEST['eyecandy_page_option']);
        $correto = true;
    }
    
    if ($_REQUEST['c2_slide']) {
     $default_c2_slide = get_option('c2_slide');
        update_option('c2_slide', $default_c2_slide);
        $correto = true;
    }
    
    if ($_FILES['uploadfiles']) {
    
       if($_FILES["uploadfiles"]["type"]=='audio/mp3' || $_FILES["uploadfiles"]["type"]=='audio/wav'){
      $upload = wp_upload_bits($_FILES["uploadfiles"]["name"], null, file_get_contents($_FILES["uploadfiles"]["tmp_name"]));
      update_option('c2_audio', $_FILES["uploadfiles"]["name"]);
        $correto = true;
}

    }

    
    
    if ($correto) {
        ?><div id="message" class="updated fade">
            <p><?php _e('Settings saved'); ?></p>
        </div> <?php
    } 
}


// Forms for Popup Setting options
function print_eyecandyslider_form() {
  
        $eyecandyslider_style = get_option('eyecandyslider_style');
        $eyecandyslider_cookie = get_option('eyecandyslider_cookie');
        $eyecandyslider_plugin_dir = plugin_dir_url(__FILE__);
        $default_c2_eyecandyslider = get_option('c2_eyecandyslider');
        $default_c2_popupcontent = get_option('c2_popupcontent');
        $default_c2_popuptitle = get_option('c2_popuptitle');
        $slidername = get_option('slidername');
        $readmore= get_option('readmore');
        $default_c2_drop = get_option('c2_drop');
        $default_c2_drophor = get_option('c2_drophor');
        $default_c2_dropver = get_option('c2_dropver');
        $default_c2_dropblur = get_option('c2_dropblur');
        $default_c2_dropcolor = get_option('c2_dropcolor');
        $default_c2_bortype = get_option('c2_bortype');
        $default_c2_borcolor =get_option('c2_borcolor');
        $default_c2_height =get_option('c2_height');
        $default_c2_width =get_option('c2_width');
        $default_c2_tempbg =get_option('c2_tempbg');
        $default_c2_popupbg =get_option('c2_popupbg');
        $default_c2_transbg =get_option('c2_transbg');
        $default_c2_borwidth =get_option('c2_borwidth');
        $default_c2_rc =get_option('c2_rc');
        $default_c2_top =get_option('c2_top');
        $default_c2_left =get_option('c2_left');
        $eyecandy_page_option =get_option('eyecandy_page_option');
        $default_c2_slide =get_option('c2_slide');
        $c2_timer =get_option('c2_timer');
        $default_c2_bottom =get_option('c2_bottom');
        $default_c2_right =get_option('c2_right');
        $c2_audio =get_option('c2_audio');
    ?>

<!-- Tabs Section start here-->
<ul class="tabs" name="tabs" id="tabs">
<li><a href="#"  class="current"  style='color:blue;font-weight:bold;' id="tab1_link">Basic Settings</a></li>
<li><a href="#"  style='color:blue;font-weight:bold;' id="tab2_link">Content Settings</a></li>
<li><a href="#"  style='color:blue;font-weight:bold;' id="tab3_link">Customize Slider Settings</a></li>
<li><a href="#"  style='color:blue;font-weight:bold;' id="tab4_link">Advanced Settings</a></li>
</ul>
<!--Tab 0 section for Basic Settings

<script type="text/javascript">
  //jquery for Color picker
jQuery(document).ready(function($){
    $('.my-color-field').wpColorPicker();
});
</script>-->
<div class="tab_current" id="tab1">
    <form action="" method="post" enctype="multipart/form-data">
        <h3 style="margin: 20px 0 -5px;"><?php _e('Basic Settings'); ?></h3>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="eyecandyslider_style_default"><?php _e('Enable/Disable Slider'); ?></label></th>
                <td>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="eyecandyslider_style_default" name="eyecandyslider_style" value="default" <?php if ($eyecandyslider_style == "default") { _e('checked="checked"'); }?> />
                    <div style="margin-left: 20px;">Enabled</div>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="eyecandyslider_show" name="eyecandyslider_style" value="Disabled" <?php if ($eyecandyslider_style == "Disabled") { _e('checked="checked"'); } ?> />
                    <div style="margin-left: 20px;">Disabled</div>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="eyecandyslider_cookie_default"><?php _e('Enable/Disable Cookies'); ?></label></th>
                <td>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="eyecandyslider_cookie_default" name="eyecandyslider_cookie" value="default" <?php if ($eyecandyslider_cookie == "default") { _e('checked="checked"'); }?> />
                    <div style="margin-left: 20px;">Enabled</div>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="eyecandyslider_cookie_show" name="eyecandyslider_cookie" value="Disabled" <?php if ($eyecandyslider_cookie == "Disabled") { _e('checked="checked"'); } ?> />
                    <div style="margin-left: 20px;">Disabled</div>
                </td>
                </td>
            </tr>
			<tr>
                <th scope="row"><label for="c2_eyecandyslider"><?php _e('Cookie Duration'); ?></label></th>
                <td>
                    <input type="text" class="regular-text" id="c2_eyecandyslider" style="width: 300px;" name="c2_eyecandyslider" value="<?php echo stripcslashes($default_c2_eyecandyslider); ?>" />
                    <br/>
                    <span class="description">You can use cookies to set the display Frequency of your choice.</br> If you set the cookies to 7 days, that means that slider will only show once every 7 days for returning visitors to your site.</span>
                </td>
            </tr>
            
            <tr>
              <th scope="row"><img src="<?php echo plugins_url();?>/bottom-page-post-eye-candy-slider/images/warning_512.png" height="40" width="40"><label for="eyecandy"><?php _e('Warning! A cookie for the slider is currently set on your computer, therefore your slider won"t display '); ?></label></th>
                <td>
                  <button class="button-primary warning" id="clear_cookies" name="eyecandy_settings[clear_cookies]" value="" onclick="return clearCookie('popup_user_login');">Delete Cookies</button>
                                 
                </td>
            </tr>
            <script>
			// Function for Placement mechanism
			function bgchange8()
  {
	  var v;
v=document.getElementById('eyecandy_page_option').value;

if(v==1)
{
	document.getElementById('automatic').style.display='';

	document.getElementById('shortcode').style.display='none';	
document.getElementById('shortcode1').style.display='none';	
  document.getElementById('automatic1').style.display='none';		
}

if(v==3)

{
	document.getElementById('shortcode').style.display='';	
	
	document.getElementById('automatic').style.display='none';
  document.getElementById('shortcode1').style.display='none';	
  document.getElementById('automatic1').style.display='none';	
}
  }
			</script>
            
            <tr>
                <th scope="row"><label for="eyecandy_page_option"> Placement mechanism </label></th>
                <td>
                    <select name="eyecandy_page_option" id="eyecandy_page_option" onchange="bgchange8()">
<option value ="1" <?php if($eyecandy_page_option=='1') echo 'selected'; ?> >Automatic </option>

<option value ="3" <?php if($eyecandy_page_option=='3') echo 'selected'; ?> >Manual </option>
</select>
                </td>
            </tr>
            <?php if($eyecandy_page_option=='1') { ?>
            <tr valign="top" id="automatic1"><td scope="row" ></td><td>(Popup will load in all pages)</td>

</tr>
            <?php } elseif($eyecandy_page_option=='3'){?>
            <tr valign="top" id="shortcode1"><td scope="row"></td><td>Use this short code in your pages - [eyecandy_default_code]</td>
</tr>
            <?php }?>
            <tr valign="top" id="automatic"  style="display: none"><td scope="row" ></td><td>(Popup will load in all pages)</td>

</tr>

<tr valign="top" id="shortcode"  style="display: none"><td scope="row"></td><td>Use this short code in your pages - [eyecandy_default_code]</td>
</tr>
            
        </table>
        <p class="submit">
            <?php wp_nonce_field('eyecandyslider_nonce_action', 'eyecandyslider_nonce_field'); ?>
            <input type="submit" class="button-primary" name="submit" value="Save Changes" />
        </p>
    </form>
</div>

<!--Tab 1 section for Content Settings-->
<div class="tab" id="tab2">
  <form action="" method="post" enctype="multipart/form-data">
        <h3 style="margin: 20px 0 -5px;"><?php _e('Content Settings'); ?></h3>
        <table class="form-table">
            
            <tr>
                <th scope="row"><label for="c2_popuptitle"><?php _e('Slider Headline'); ?></label></th>
                <td>
                   <input type="text" name="c2_popuptitle" id="c2_popuptitle" value="<?php echo stripcslashes($default_c2_popuptitle); ?>">
                </td>
            </tr>
            
			<tr>
                <th scope="row"><label for="c2_popupcontent"><?php _e('Slider Content'); ?></label></th>
                <td>
				
                  <?php wp_editor(stripcslashes($default_c2_popupcontent),'c2_popupcontent');?>

                </td>
            </tr>
             <tr>
                <th scope="row"><label for="slidername"><?php _e('Slider Name'); ?></label></th>
                <td>
                   <input type="text" name="slidername" id="slidername" value="<?php echo stripcslashes($slidername); ?>">
                </td>
            </tr>
             <tr>
                <th scope="row"><label for="readmore"><?php _e('Read More Link'); ?></label></th>
                <td>
                   <input type="text" name="readmore" id="readmore" value="<?php echo $readmore;?>">
                </td>
            </tr>
            <!--<tr>
                <th scope="row"><label for="c2_timer"><?php _e('Upload Audio'); ?></label></th>
                <td>
<input type="file" name="uploadfiles" id="uploadfiles"  /><?php echo $c2_audio; ?>

                </td>
                
            </tr>-->
        </table>
        <p class="submit">
            <?php wp_nonce_field('eyecandyslider_nonce_action', 'eyecandyslider_nonce_field'); ?>
            <input type="submit" class="button-primary" name="submit" value="Save Changes" />
        </p>
    </form>
</div>
<!--Tab 2 section for DropShadow Settings-->
<div class="tab" id="tab3">
  <script>
  // jquery for dragger
  window.addEvent('domready', function(){

  var slider = $('slider');
  var slider1 = $('slider1');
  var slider2 = $('slider2');
  var slider3 = $('slider3');
  var slider4 = $('slider4');
  var slider5 = $('slider5');
  var slider6 = $('slider6');
 

  new Slider(slider, slider.getElement('.knob'), {
    range: [100, 500],
    initialStep: <?php echo $default_c2_height;?>,
    onChange: function(value){
      if (value) $('c2_height').set('value', value+'px');
    }
  });
  
  new Slider(slider1, slider1.getElement('.knob'), {
    range: [100, 500],
    initialStep: <?php echo $default_c2_width;?>,
    onChange: function(value){
      if (value) $('c2_width').set('value', value+'px');
    }
  });
  new Slider(slider2, slider2.getElement('.knob'), {
    range: [1, 5],
    initialStep: <?php echo $default_c2_borwidth;?>,
    onChange: function(value){
      if (value) $('c2_borwidth').set('value', value+'px');
    }
  });
  new Slider(slider3, slider3.getElement('.knob'), {
    range: [1, 10],
    initialStep: <?php echo $default_c2_rc;?>,
    onChange: function(value){
      if (value) $('c2_rc').set('value', value+'px');
    }
  });
new Slider(slider4, slider4.getElement('.knob'), {
    range: [1, 10],
    initialStep: <?php echo $default_c2_dropblur;?>,
    onChange: function(value){
      if (value) $('c2_dropblur').set('value', value+'px');
    }
  });
  
  new Slider(slider5, slider5.getElement('.knob'), {
    range: [1, 10],
    initialStep: <?php echo $default_c2_dropver;?>,
    onChange: function(value){
      if (value) $('c2_dropver').set('value', value+'px');
    }
  });

new Slider(slider6, slider6.getElement('.knob'), {
    range: [1, 10],
    initialStep: <?php echo $default_c2_drophor;?>,
    onChange: function(value){
      if (value) $('c2_drophor').set('value', value+'px');
    }
  });
  

});
// end of jquery for dragger
  </script>
  <form action="" method="post" enctype="multipart/form-data">
        <h3 style="margin: 20px 0 -5px;"><?php _e('Customize Slider Settings'); ?></h3>
        <table class="form-table">
          <tr>
                <th scope="row"><label for="c2_drop"><?php _e('Customize Slider Settings'); ?></label></th>
               
                <td>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="c2_drop_default" name="c2_drop" value="default" <?php if ($default_c2_drop == "default") { _e('checked="checked"'); }?> />
                    <div style="margin-left: 20px;">Enabled</div>
                    <input style="margin:0 0 -15px;padding:0;display:block" type="radio" id="c2_drop_show" name="c2_drop" value="Disabled" <?php if ($default_c2_drop == "disabled") { _e('checked="checked"'); } ?> />
                    <div style="margin-left: 20px;">Disabled</div>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="c2_drophor"><?php _e('Horizontal Shadow'); ?></label></th>
                <td>
                  <div id="slider6" class="slider">
  <div class="knob"></div>
</div>
                   <input type="text" name="c2_drophor" id="c2_drophor" value="" readonly>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="c2_dropver"><?php _e('Vertical Shadow'); ?></label></th>
                <td>
                  <div id="slider5" class="slider">
                  <div class="knob"></div>
                  </div>
                   <input type="text" name="c2_dropver" id="c2_dropver" value="" readonly>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="c2_dropblur"><?php _e('Blur Amount'); ?></label></th>
                <td>
                  <div id="slider4" class="slider">
  <div class="knob"></div>
</div>
                   <input type="text" name="c2_dropblur" id="c2_dropblur" value="" readonly>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="c2_dropcolor"><?php _e('Shadow Color'); ?></label></th>
                <td>
                   <!--<input type="text" name="c2_dropcolor" id="c2_drophor" value="<?php echo stripcslashes($default_c2_dropcolor); ?>">-->
                   <input type="text" value="<?php echo stripcslashes($default_c2_dropcolor); ?>" data-default-color="#bada55" name="c2_dropcolor" id="c2_drophor" class="my-color-field"/>
                </td>
            </tr>
            
			
        </table>
        <p class="submit">
            <?php wp_nonce_field('eyecandyslider_nonce_action', 'eyecandyslider_nonce_field'); ?>
            <input type="submit" class="button-primary" name="submit" value="Save Changes" />
        </p>
    </form>
</div>
<!--Tab 3 section for PopUp Settings-->
<div class="tab" id="tab4">
  <form action="" method="post" enctype="multipart/form-data">
        <h3 style="margin: 20px 0 -5px;"><?php _e('Advanced Settings'); ?></h3>
        <table class="form-table">
          <tr>
                <th scope="row"><label for="c2_height"><?php _e('Slider Height'); ?></label></th>
  
                <td>
                  <div id="slider" class="slider">
  <div class="knob"></div>
</div>
<input type="text" name="c2_height" id="c2_height" value="" readonly>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="c2_width"><?php _e('Slider Width'); ?></label></th>
                <td>
                  <div id="slider1" class="slider">
  <div class="knob"></div>
</div>
<input type="text" name="c2_width" id="c2_width" value="" readonly>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="c2_borwidth"><?php _e('Border Width'); ?></label></th>
                <td>
                  <div id="slider2" class="slider">
  <div class="knob"></div>
</div>
                   <input type="text" name="c2_borwidth" id="c2_borwidth" value="" readonly>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="c2_rc"><?php _e('Round Corners'); ?></label></th>
                <td>
                  <div id="slider3" class="slider">
  <div class="knob"></div>
</div>
                   <input type="text" name="c2_rc" id="c2_rc" value="" readonly>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="c2_borcolor"><?php _e('Border Color'); ?></label></th>
                <td>
                   <input type="text" value="<?php echo stripcslashes($default_c2_borcolor); ?>" data-default-color="#bada55" name="c2_borcolor" id="c2_borcolor" class="my-color-field"/>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="c2_bortype"><?php _e('Border Type'); ?></label></th>
                <td>
                  <select name="c2_bortype" id="c2_bortype">
                   
                    <option value="solid"  <?php if($default_c2_bortype=='solid'){?> select="selected" <?php }?>>Solid</option>
                    <option value="dashed" <?php if($default_c2_bortype=='dashed'){?> select="selected" <?php }?>>Dashed</option>
                    
                  </select>
                   
                </td>
            </tr>
            <!--<tr>
                <th scope="row"><label for="c2_slide"> <?php _e('Slide Effect'); ?> </label></th>
                <td>
                    <select name="c2_slide" id="c2_transbg">
                      <option value ="null">Select </option>
<option value ="left" <?php if($default_c2_slide=='left') echo 'selected'; ?> >Left </option>

<option value ="right" <?php if($default_c2_slide=='right') echo 'selected'; ?> > Right</option>
<option value ="top" <?php if($default_c2_slide=='top') echo 'selected'; ?> >Top </option>

<option value ="bottom" <?php if($default_c2_slide=='bottom') echo 'selected'; ?> > Bottom</option>
</select>
                </td>
            </tr>-->
            
          
            
        </table>
        <p class="submit">
            <?php wp_nonce_field('eyecandyslider_nonce_action', 'eyecandyslider_nonce_field'); ?>
            <input type="submit" class="button-primary" name="submit" value="Save Changes" />
        </p>
    </form>
</div>
<!--End Of Tab Sections-->
<!--Author Description-->
  <div style="background: white;border: 1px solid #ccc;width: 100%;height: 50px;float: left;font-family: Arial,sans-serif;font-size: 15px;margin-right: 20px;float: left;">
  <strong style="display: block;border: 1px solid #ccc;border-left: 0;border-right: 0;margin-top: 10px;width: 350px;margin: 0 auto;margin-top: 10px;padding-top: 5px;padding-bottom: 5px;text-align: center;">Plugin developed by www.InternetMarketingScout.com</strong>

  </div>
<!-- End Of Author Description--->
<?php
    }

// JS and Jquery Included For PopUp Display in Frontend
if (get_option('eyecandyslider_style') == 'default') {
    
    
    function eyecandyslider_enqueue_script() {
      $mini_dir = plugin_dir_url(__FILE__);

      wp_enqueue_script('jquery');
      wp_register_style('drop_shadow_popup_style', $mini_dir . 'css/style.css');
      wp_enqueue_style('drop_shadow_popup_style');
      wp_register_script('query_cookie', $mini_dir . 'js/jquery.cookie.js');
      wp_enqueue_script('query_cookie');
      wp_register_script('player', $mini_dir . 'js/jquery.jplayer.min.js');
      wp_enqueue_script('player');
    }
    
  // Add Popup script in Front end  
    add_action('wp_enqueue_scripts', 'eyecandyslider_enqueue_script');
function eyecandyslider_add_style() {
    
      $default_c2_drop = get_option('c2_drop');
      $default_c2_drophor = get_option('c2_drophor');
      $default_c2_dropver = get_option('c2_dropver');
      $default_c2_dropblur = get_option('c2_dropblur');
      $default_c2_dropcolor = get_option('c2_dropcolor');
       $default_c2_bortype = get_option('c2_bortype');
      $default_c2_borcolor =get_option('c2_borcolor');
      $default_c2_height =get_option('c2_height');
      $default_c2_width =get_option('c2_width');
      $default_c2_tempbg =get_option('c2_tempbg');
      $default_c2_popupbg =get_option('c2_popupbg');
      $default_c2_transbg =get_option('c2_transbg');
      $default_c2_borwidth =get_option('c2_borwidth');
      $default_c2_rc =get_option('c2_rc');
      $default_c2_top =get_option('c2_top');
      $default_c2_left =get_option('c2_left');
      $default_c2_slide =get_option('c2_slide');
      $c2_timer =get_option('c2_timer');
      $default_c2_bottom =get_option('c2_bottom');
      $default_c2_right =get_option('c2_right');
      $c2_audio =get_option('c2_audio');
      $upload= wp_upload_dir();
      $audio=$upload['url'].'/'.$c2_audio;
       $rgba = hex2rgba($default_c2_tempbg, 0.8);?>
<p id="last">&nbsp;</p>
 <?php 
$popupcontent = $wpdb->prefix . 'popupcontent';
$sql = $wpdb->prepare("SELECT * FROM $popupcontent WHERE `slug` = %s", $post->post_name);
            $result = $wpdb->get_results($sql, ARRAY_A);
            $row = $result[0];
            if($row['popup_id']==''){?>
<style type="text/css" >
#slidebox{
    width:<?php echo $default_c2_width;?>px;
    height:<?php echo $default_c2_height;?>px;
    padding:10px;
   
    -webkit-border-radius:<?php echo $default_c2_rc;?>px;
      -moz-border-radius:<?php echo $default_c2_rc;?>px;
      border-radius:<?php echo $default_c2_rc;?>px;
      border-color: <?php echo $default_c2_borcolor;?> !important ;
      border: <?php echo $default_c2_bortype;?> <?php echo $default_c2_borwidth;?>px; opacity:1.0 !important; filter:Alpha(opacity=0) !important;  
    position:fixed;
    bottom:20px;
    right:-600px;
     
}
a.close{
    width:13px;
    height:13px;
    position:absolute;
    cursor:pointer;
    top:10px;
    right:10px;
}
.shadow {
     <?php if($default_c2_drop=='default'){ ?>
      -moz-box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px  <?php echo $default_c2_dropcolor;?>!important;
      -webkit-box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px <?php echo $default_c2_dropcolor;?> !important;
      box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px <?php echo $default_c2_dropcolor;?> !important;
      /* For IE 8 */
      -ms-filter:"progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000')";
      /* For IE 5.5 - 7 */
      filter:progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000');
      <?php }?>
}
</style>
<?php }
else {?>
<style type="text/css" >
#slidebox{
    width:<?php echo $row['c2_width'];?>px;
    height:<?php echo $row['c2_height'];?>px;
    padding:10px;
   
    -webkit-border-radius:<?php echo $row['c2_rc'];?>px;
      -moz-border-radius:<?php echo $row['c2_rc'];?>px;
      border-radius:<?php echo $row['c2_rc'];?>px;
      border-color: <?php echo $row['c2_borcolor'];?> !important ;
      border: <?php echo $row['c2_bortype'];?> <?php echo $row['c2_borwidth'];?>px; opacity:1.0 !important; filter:Alpha(opacity=0) !important;  
    position:fixed;
    bottom:20px;
    right:-600px;
     
}
a.close{
    width:13px;
    height:13px;
    position:absolute;
    cursor:pointer;
    top:10px;
    right:10px;
}
.shadow {
    <?php if($default_c2_drop=='default'){ ?>
      -moz-box-shadow:<?php echo $row['c2_drophor'];?>px <?php echo $row['c2_dropver'];?>px <?php echo $row['c2_dropblur'];?>px  <?php echo $row['c2_dropcolor'];?>!important;
      -webkit-box-shadow:<?php echo $row['c2_drophor'];?>px <?php echo $row['c2_dropver'];?>px <?php echo $row['c2_dropblur'];?>px <?php echo $row['c2_dropcolor'];?> !important;
      box-shadow:<?php echo $row['c2_drophor'];?>px <?php echo $row['c2_dropver'];?>px <?php echo $row['c2_dropblur'];?>px <?php echo $row['c2_dropcolor'];?> !important;
      /* For IE 8 */
      -ms-filter:"progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000')";
      /* For IE 5.5 - 7 */
      filter:progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000');
      <?php }?>
}
</style> 
  
<?php }

?>
       
<?php }
   // PopUp Display
  function eyecandyslider_add_box() {
	$eyecandyslider_plugin_dir = plugin_dir_url(__FILE__);
	$default_c2_eyecandyslider = get_option('c2_eyecandyslider');
	$default_c2_popupcontent = get_option('c2_popupcontent');
	$default_c2_popuptitle = get_option('c2_popuptitle');
  $page_option=get_option('eyecandy_page_option');
  $c2_audio =get_option('c2_audio');
  $default_c2_drop = get_option('c2_drop');
  
      $default_c2_drophor = get_option('c2_drophor');
      $default_c2_dropver = get_option('c2_dropver');
      $default_c2_dropblur = get_option('c2_dropblur');
      $default_c2_dropcolor = get_option('c2_dropcolor');
      $default_c2_bortype = get_option('c2_bortype');
      $default_c2_borcolor =get_option('c2_borcolor');
      $default_c2_height =get_option('c2_height');
      $default_c2_width =get_option('c2_width');
      $default_c2_tempbg =get_option('c2_tempbg');
      $default_c2_popupbg =get_option('c2_popupbg');
      $default_c2_transbg =get_option('c2_transbg');
      $default_c2_borwidth =get_option('c2_borwidth');
      $default_c2_rc =get_option('c2_rc');
      $default_c2_top =get_option('c2_top');
      $default_c2_left =get_option('c2_left');
      $default_c2_slide =get_option('c2_slide');
      $c2_timer =get_option('c2_timer');
      $default_c2_bottom =get_option('c2_bottom');
      $default_c2_right =get_option('c2_right');
      $c2_audio =get_option('c2_audio');
      $upload= wp_upload_dir();
      $audio=$upload['url'].'/'.$c2_audio;
       $rgba = hex2rgba($default_c2_tempbg, 0.8);
       global $post , $wpdb;
       $slidername = get_option('slidername');
        $readmore= get_option('readmore');
        $exturl = get_option('exturl');
  ?>

  <p id="last">&nbsp;</p>
  
<style type="text/css" >
#slidebox{
background-color:<?php echo $default_c2_popupbg;?>;
    width:<?php echo $default_c2_width;?>px;
    height:<?php echo $default_c2_height;?>px;
    padding:10px;
   
    -webkit-border-radius:<?php echo $default_c2_rc;?>px;
      -moz-border-radius:<?php echo $default_c2_rc;?>px;
      border-radius:<?php echo $default_c2_rc;?>px;
      border-color: <?php echo $default_c2_borcolor;?> !important ;
      border: <?php echo $default_c2_bortype;?> <?php echo $default_c2_borwidth;?>px; opacity:1.0 !important; filter:Alpha(opacity=0) !important;  
    position:fixed;
    bottom:20px;
    right:-600px;
     
}
a.close{
    width:13px;
    height:13px;
    position:absolute;
    cursor:pointer;
    top:10px;
    right:10px;
}
.shadow {
      <?php if($default_c2_drop=='default'){ ?>
      -moz-box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px  <?php echo $default_c2_dropcolor;?>!important;
      -webkit-box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px <?php echo $default_c2_dropcolor;?> !important;
      box-shadow:<?php echo $default_c2_drophor;?>px <?php echo $default_c2_dropver;?>px <?php echo $default_c2_dropblur;?>px <?php echo $default_c2_dropcolor;?> !important;
      /* For IE 8 */
      -ms-filter:"progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000')";
      /* For IE 5.5 - 7 */
      filter:progid:DXImageTransform.Microsoft.Shadow(Strength=4, Direction=135, Color='#000000');
      <?php }?>
      }
      
</style>



    <div id="slidebox" class="shadow">

                      <h2><?php echo stripcslashes($default_c2_popuptitle); 
                     
                    ?></h2>
			</br>
			<?php echo do_shortcode(stripcslashes($default_c2_popupcontent));
                
      echo '<br>';
      if($readmore){?>
      <a href="<?php echo $readmore;?>" class="readmore">Read More</a>
           <?php }?>
      <div id="jquery_jplayer_1"></div>
</div>
 


	<?php
    }
    
    function eyecandyslider_add()
    {
      add_filter('wp_footer', 'eyecandyslider_add_box');
    }
    /* Convert hexdec color string to rgb(a) string */

function hex2rgba($color, $opacity = false) {

	$default = 'rgb(0,0,0)';

	//Return default if no color provided
	if(empty($color))
          return $default; 

	//Sanitize $color if "#" is provided 
        if ($color[0] == '#' ) {
        	$color = substr( $color, 1 );
        }

        //Check if color has 6 or 3 characters and get values
        if (strlen($color) == 6) {
                $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
        } elseif ( strlen( $color ) == 3 ) {
                $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
        } else {
                return $default;
        }

        //Convert hexadec to rgb
        $rgb =  array_map('hexdec', $hex);

        //Check if opacity is set(rgba or rgb)
        if($opacity){
        	if(abs($opacity) > 1)
        		$opacity = 1.0;
        	$output = 'rgba('.implode(",",$rgb).','.$opacity.')';
        } else {
        	$output = 'rgb('.implode(",",$rgb).')';
        }

        //Return rgb(a) color string
        return $output;
}
	   
    function eyecandyslider_js_add_box() {
    
      $default_c2_drop = get_option('c2_drop');
      $default_c2_drophor = get_option('c2_drophor');
      $default_c2_dropver = get_option('c2_dropver');
      $default_c2_dropblur = get_option('c2_dropblur');
      $default_c2_dropcolor = get_option('c2_dropcolor');
      $default_c2_bortype = get_option('c2_bortype');
      $default_c2_borcolor =get_option('c2_borcolor');
      $default_c2_height =get_option('c2_height');
      $default_c2_width =get_option('c2_width');
     $default_c2_tempbg =get_option('c2_tempbg');
      $default_c2_borwidth =get_option('c2_borwidth');
      $default_c2_rc =get_option('c2_rc');
      $default_c2_top =get_option('c2_top');
      $default_c2_left =get_option('c2_left');
      $default_c2_slide =get_option('c2_slide');
      $c2_timer =get_option('c2_timer');
      $default_c2_bottom =get_option('c2_bottom');
      $default_c2_right =get_option('c2_right');
      $c2_audio =get_option('c2_audio');
      $upload= wp_upload_dir();
      $audio=$upload['url'].'/'.$c2_audio;
       $rgba = hex2rgba($default_c2_tempbg, 0.8);
       $default_c2_eyecandyslider = get_option('c2_eyecandyslider');
       $eyecandyslider_cookie = get_option('eyecandyslider_cookie');
       
        ?>

<!--eyecandy JS -->
<?php 
if($eyecandyslider_cookie=='default') {?>
<script type="text/javascript">
jQuery(document).ready(function($) {
  if($.cookie('popup_user_login')!='yes'){
$(window).scroll(function(){
/*Let's get the distance from the top to the element */
var distanceTop = $('#last').offset().top - $(window).height();
//alert(distanceTop);
if ($(window).scrollTop() > distanceTop){
$('#slidebox').animate({'right':'0px'},300);
// Player start here
	$("#jquery_jplayer_1").jPlayer({
        ready: function() {
          setTimeout(function(player) {
         $(this).jPlayer("setMedia", {
            mp3: "<?php echo $audio; ?>"
          }).jPlayer("stop");
     }, <?php echo $c2_timer;?>000);
     $(this).jPlayer("setMedia", {
            mp3: "<?php echo $audio; ?>"
          }).jPlayer("play");
          
          var click = document.ontouchstart === undefined ? 'click' : 'touchstart';
          var kickoff = function () {
            $("#jquery_jplayer_1").jPlayer("play");
            document.documentElement.removeEventListener(click, kickoff, true);
			
          };
          document.documentElement.addEventListener(click, kickoff, true);
        },
		
        swfPath: "/js"
      });
	// Player end here  
  }
else{
$('#slidebox').stop(true).animate({'right':'-600px'},100);
}
});

/* remove the slidebox when clicking the cross */
$('#slidebox .close').bind('click',function(){
jQuery(this).parent().remove();
$("#jquery_jplayer_1").jPlayer("stop");
});
}
$.cookie('popup_user_login','yes',{path:'/',expires:<?php echo $default_c2_eyecandyslider; ?>})

});

</script>
<?php }
elseif($eyecandyslider_cookie=='Disabled'){
?>
<script type="text/javascript">
jQuery(document).ready(function($) {
$(window).scroll(function(){
/*Let's get the distance from the top to the element */
var distanceTop = $('#last').offset().top - $(window).height();
//alert(distanceTop);
if ($(window).scrollTop() > distanceTop){
$('#slidebox').animate({'right':'0px'},300);
// Player start here
	$("#jquery_jplayer_1").jPlayer({
        ready: function() {
          setTimeout(function(player) {
         $(this).jPlayer("setMedia", {
            mp3: "<?php echo $audio; ?>"
          }).jPlayer("stop");
     }, <?php echo $c2_timer;?>000);
     $(this).jPlayer("setMedia", {
            mp3: "<?php echo $audio; ?>"
          }).jPlayer("play");
          
          var click = document.ontouchstart === undefined ? 'click' : 'touchstart';
          var kickoff = function () {
            $("#jquery_jplayer_1").jPlayer("play");
            document.documentElement.removeEventListener(click, kickoff, true);
			
          };
          document.documentElement.addEventListener(click, kickoff, true);
        },
		
        swfPath: "/js"
      });
	// Player end here  
  }
else{
$('#slidebox').stop(true).animate({'right':'-600px'},100);
}
});

/* remove the slidebox when clicking the cross */
$('#slidebox .close').bind('click',function(){
jQuery(this).parent().remove();
$("#jquery_jplayer_1").jPlayer("stop");
});
});

</script>
<?php }

}// 
    $page_option=get_option('eyecandy_page_option');
    //Shortcode Implementation 
if($page_option==3)
{
  add_action('after_body', 'eyecandyslider_add_style');
  add_shortcode( 'eyecandy_default_code', 'eyecandyslider_add' );
 
}
if($page_option==1)
{
  add_filter('wp_footer', 'eyecandyslider_add_box');
}  
	add_filter('wp_head', 'eyecandyslider_js_add_box');
}

add_action('admin_notices', 'eycn_admin_notice');
function eycn_admin_notice() {


if (isset($_GET["page"])=='bottom-page-post-eye-candy-slider') {
            echo "<a href='http://internetmarketingscout.com/eyecandyslider/' id='upgrade_e_s' class='add-new-h2' style='display:none;'>Want To Add Different Sliders To Pages/Posts? Upgrade To Pro!</a>";
}
			}
?>