 jQuery(document).ready(function($){
    $('.my-color-field').wpColorPicker();
	$("#upgrade_e_s").appendTo('h2');
	$("#upgrade_e_s").show();	
	});