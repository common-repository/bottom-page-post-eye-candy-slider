=== Bottom Page Post Eye Candy Slider ===
Contributors: duncan2222
Donate link: http://www.internetmarketingscout.com/donateplugin/
Tags: banner ads,banners,page,post
Requires at least: 3.7.1
Tested up to: 3.8
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add an eye catching slide in feature to the bottom of any page or post.

== Description ==

Add an eye catching slide in feature to the bottom of any page or post. Embed, video, pictures, FB like buttons, plain text, buy now buttons, etc. 


== Installation ==


1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==
http://internetmarketingscout.com/wpdirectoryecsscreenshots/

== Changelog ==

= 1.0 =
* No Changes.

== Upgrade Notice ==

= 1.0 =
Upgrade to the pro version that allows you to put a slider on as many pages or posts that you like. 


== Arbitrary section ==

None
